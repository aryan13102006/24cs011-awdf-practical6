import { NavLink } from 'react-router-dom';

function NavBar({ darkMode, setDarkMode }) {
  return (
    <header className="navbar-container">
      <nav className="navbar">
        <div className="nav-brand">
          <div className="brand-badge">DL</div>
          <div className="brand-details">
            <span className="brand-name">Aryan Chanpa</span>
            <span className="brand-sub">ID: 24CS011</span>
          </div>
        </div>
        <div className="nav-links">
          <NavLink 
            to="/" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Home
          </NavLink>
          <NavLink 
            to="/tasks" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Tasks (Full-Stack)
          </NavLink>
          <NavLink 
            to="/projects" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            GitHub
          </NavLink>
          <NavLink 
            to="/contact" 
            className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}
          >
            Contact
          </NavLink>
          <button 
            type="button"
            className="theme-toggle-btn" 
            onClick={() => setDarkMode(!darkMode)}
            title="Toggle Dark / Light Theme"
          >
            {darkMode ? '☀️ Light' : '🌙 Dark'}
          </button>
        </div>
      </nav>
    </header>
  );
}

export default NavBar;
